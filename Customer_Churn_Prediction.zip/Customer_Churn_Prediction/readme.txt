🧠 Customer Churn Prediction — Machine Learning Project
📋 Overview
This project predicts whether a telecom customer will churn (leave the company) or stay, using historical customer data.
The goal is to help businesses identify at-risk customers early so they can take retention actions.

Dataset used: Telco Customer Churn Dataset (Kaggle)
👉 Download Dataset: https://www.kaggle.com/blastchar/telco-customer-churn

🚀 Project Highlights

🧩 End-to-End ML Pipeline: Data cleaning, preprocessing, model training, and evaluation.

🤖 Algorithms Used: Logistic Regression, Random Forest, and Gradient Boosting.

📊 Feature Engineering: Label Encoding, Missing value handling, and Scaling.

💡 Evaluation Metrics: Accuracy, ROC-AUC, Confusion Matrix, and Feature Importance.

🌐 Interactive Web App: Built with Streamlit for live churn predictions.

🗂️ Repository Structure
CUSTOMER_CHURN_PREDICTION/
│
├── churn_model_training.ipynb     # Full training notebook (EDA, modeling, visualization)
├── app.py                         # Streamlit web app for live predictions
├── requirements.txt               # Dependencies
├── README.md                      # Project documentation

⚙️ Installation and Setup
Step 1: Clone the Repository
git clone https://github.com/soojalkumar337/Customer_Churn_Prediction.git
cd Customer_Churn_Prediction

Step 2: Install Required Packages
pip install -r requirements.txt

Step 3: Download Dataset

Download Telco Customer Churn dataset from Kaggle and place it inside the project folder.
Filename should be:

WA_Fn-UseC_-Telco-Customer-Churn.csv

Step 4: Train the Model

You can  run the Jupyter Notebook:

jupyter notebook churn_model_training.ipynb


This will create two files:

churn_model.pkl
scaler.pkl

Step 5: Launch the Streamlit App
streamlit run app.py

🧾 Example Prediction

Input Example:

Gender	SeniorCitizen	Partner	Dependents	Tenure	MonthlyCharges	TotalCharges
Male	0	Yes	No	12	75.5	850.0

Output:
⚠️ Predicted: Churn (Probability: 73.21%)
or
✅ Predicted: Stay (Probability: 86.54%)

🧰 Technologies Used

Python 3.x

NumPy, Pandas, Scikit-learn

Matplotlib, Seaborn

Streamlit

Joblib

📈 Future Enhancements

Integrate SHAP or LIME for explainable AI.

Add interactive dashboard (Plotly/Streamlit charts).

Deploy to Streamlit Cloud or Heroku.

Use SMOTE for handling imbalanced data.

👨‍💻 Developed by:

Soojal Kumar
📧 Email: kumarsoojal55@gmail.com